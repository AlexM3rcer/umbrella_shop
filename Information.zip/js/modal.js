$('.modal-button').on('click', function() {
  location.href = 'information.php'
});
